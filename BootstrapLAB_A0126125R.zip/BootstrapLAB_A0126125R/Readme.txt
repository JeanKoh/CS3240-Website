Homepage
    index.html

Description of the website
	This website is used as my biography and interests, mainly in music.

Where to locate each element in your website:
Any of the base CSS
    -Style.css
    
Any of the components
    -dropdown nav bar
    
Any of the JavaScript category item
    -Collapse.js (under music, "what do I like?)
    
Form Validation
    -Checking if name and suggestions are filled before "submitting"
    
jQuery Effects
    -opacity of profile picture in biography
    -opacity and visibility of images and texts

References you have taken
	https://www.w3schools.com/bootstrap/default.asp
	api.jquery.com
    CS3240 Lab1 and Lab2
